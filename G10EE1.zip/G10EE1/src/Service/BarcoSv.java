/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidades.Alquiler;
import Entidades.Barco;
import Entidades.BarcoAMotor;
import Entidades.Velero;
import Entidades.Yates;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * En un puerto se alquilan amarres para barcos de distinto tipo. Para cada
 * Alquiler se guarda: el nombre, documento del cliente, la fecha de alquiler,
 * fecha de devolución, la posición del amarre y el barco que lo ocupará. Un
 * Barco se caracteriza por: su matrícula, su eslora en metros y año de
 * fabricación. Sin embargo, se pretende diferenciar la información de algunos
 * tipos de barcos especiales: • Número de mástiles para veleros. • Potencia en
 * CV para barcos a motor. • Potencia en CV y número de camarotes para yates de
 * lujo. Un alquiler se calcula multiplicando el número de días de ocupación
 * (calculado con la fecha de alquiler y devolución), por un valor módulo de
 * cada barco (obtenido simplemente multiplicando por 10 los metros de eslora).
 * En los barcos de tipo especial el módulo de cada barco se calcula sacando el
 * módulo normal y sumándole el atributo particular de cada barco. En los
 * veleros se suma el número de mástiles, en los barcos a motor se le suma la
 * potencia en CV y en los yates se suma la potencia en CV y el número de
 * camarotes. Utilizando la herencia de forma apropiada, deberemos programar en
 * Java, las clases y los métodos necesarios que permitan al usuario elegir el
 * barco que quiera alquilar y mostrarle el precio final de su alquiler.
 */
public class BarcoSv {

    ArrayList<Barco> barcos = new ArrayList();
    ArrayList<Alquiler> Alqui = new ArrayList();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearBarco() {

        int i = 0;
        int n;
        do {
            System.out.println("que barco desea amarrar?");
            System.out.println("1: Yate");
            System.out.println("2: velero");
            System.out.println("3: barco a motor");
            System.out.println("4: ninguno");
            n = leer.nextInt();
            i++;
            switch (n) {
                case 1:
                    Yates y1 = new Yates();
                    y1.crearYate();
                    barcos.add(y1);
                    Alquiler a1 = new Alquiler();
                    Integer alq;
                    System.out.println("Ingrese la cantidad de dias");
                    a1.setDias(leer.nextInt());
                    alq = ((y1.getEslora()*10) * a1.getDias())+ y1.getnCamarotes() + y1.getCV();
                    System.out.println("Es un total de: " + alq);
                    System.out.println(y1);
                    a1.setBarco(y1);
                    a1.setPosAm(i);
                    Alqui.add(a1);
                    break;
                case 2:
                    Velero v1 = new Velero();
                    v1.crearVelero();
                    barcos.add(v1);
                    Alquiler a2 = new Alquiler();
                    Integer alq2;
                    System.out.println("Ingrese la cantidad de dias");
                    a2.setDias(leer.nextInt());
                     alq2 = ((v1.getEslora()*10) * a2.getDias())+ v1.getNmastil();
                     System.out.println("Es un total de: " + alq2);
                     System.out.println(v1);
                    a2.setBarco(v1);
                    a2.setPosAm(i);
                    Alqui.add(a2);
                    break;
                case 3:
                    BarcoAMotor bam1 = new BarcoAMotor();
                    bam1.crearBAM();
                    barcos.add(bam1);
                    Alquiler a3 = new Alquiler();
                    Integer alq3;
                    System.out.println("Ingrese la cantidad de dias");
                    a3.setDias(leer.nextInt());
                    alq3 = ((bam1.getEslora()*10) * a3.getDias()) + bam1.getCV();
                    System.out.println("Es un total de: " + alq3);
                    System.out.println(bam1);
                    a3.setBarco(bam1);
                    a3.setPosAm(i);
                     Alqui.add(a3);
                    break;

                case 4:
                    break;
            }
        } while (n != 4);
    }

}
