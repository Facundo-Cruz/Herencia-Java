/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author HJS Informatica
 */
public final class BarcoAMotor extends Barco{
    private Integer CV;

    public BarcoAMotor(Integer CV, String matricula, Integer eslora, Integer añoF) {
        super(matricula, eslora, añoF);
        this.CV = CV;
    }

    public Integer getCV() {
        return CV;
    }

    public void setCV(Integer CV) {
        this.CV = CV;
    }

    public BarcoAMotor() {
    }
    
    public void crearBAM(){
        super.crearBarco();
         this.CV=(int) (Math.random()*500);
    }
    @Override
    public String toString() {
        
        return super.toString() +  "BarcoAMotor{" + "CV=" + CV + '}';
    }
    
    
}
