/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 En los barcos de tipo especial el módulo de cada barco se calcula sacando el módulo normal y
sumándole el atributo particular de cada barco. En los veleros se suma el número de mástiles,
en los barcos a motor se le suma la potencia en CV y en los yates se suma la potencia en CV y
el número de camarotes. 
 */
public final class Yates extends Barco{
private Integer CV;
 private Integer  nCamarotes;  

    public Yates() {
    }

    public Yates(Integer CV, Integer nCamarotes, String matricula, Integer eslora, Integer añoF) {
        super(matricula, eslora, añoF);
        this.CV = CV;
        this.nCamarotes = nCamarotes;
    }

    public Integer getCV() {
        return CV;
    }

    public void setCV(Integer CV) {
        this.CV = CV;
    }

    public Integer getnCamarotes() {
        return nCamarotes;
    }

    public void setnCamarotes(Integer nCamarotes) {
        this.nCamarotes = nCamarotes;
    }
    
    public void crearYate(){
        super.crearBarco();
        
        this.CV = (int) (Math.random() * 20000);
        this.nCamarotes = (int) (Math.random() * 6);
        
        
    }
    @Override
    public String toString() {
     
        return    super.toString() + "Yates{" + "CV=" + CV + ", nCamarotes=" + nCamarotes + '}';
    }
  
  
}
