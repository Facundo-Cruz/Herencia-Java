/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
En los barcos de tipo especial el módulo de cada barco se calcula sacando el módulo normal y
sumándole el atributo particular de cada barco. En los veleros se suma el número de mástiles,
en los barcos a motor se le suma la potencia en CV y en los yates se suma la potencia en CV y
el número de camarotes.
 */
public final class Velero extends Barco{
   private Integer nmastil;

    public Velero() {
    }

    public Velero(Integer nmastil, String matricula, Integer eslora, Integer añoF) {
        super(matricula, eslora, añoF);
        this.nmastil = nmastil;
    }

    public Integer getNmastil() {
        return nmastil;
    }

    public void setNmastil(Integer nmastil) {
        this.nmastil = nmastil;
    }
     public void crearVelero(){
         super.crearBarco();
          this.nmastil = (int) (Math.random() * 4);
     }
    @Override
    public String toString() {
        
        return super.toString() + "Velero{" + "nmastil=" + nmastil + '}';
    }
    
    
    
}
